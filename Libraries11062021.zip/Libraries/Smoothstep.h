/*
 * Smoothstep.h
 *
 *  Created on: 09.06.2021
 *      Author: BER83WI
 */

#ifndef SMOOTHSTEP_H_
#define SMOOTHSTEP_H_

#include "main.h"

//typedef struct Smoothstep {
//	uint8_t curOrder;
//} Smoothstep_t;

float smoothstepfloat(float);
float smoothstepfloat2(float);
float smoothstepfloat3(float);
float smoothstepint(uint32_t, uint32_t, uint32_t);
float smoothstepint2(uint32_t, uint32_t, uint32_t);
float smoothstepint3(uint32_t, uint32_t, uint32_t);

float smoothstepv2(float x);
void smoothstepmaxv2(float *max, float *x);
float smoothstepa2(float x);
void smoothstepmaxa2(float *max, float *x);
void smoothstepmina2(float *min, float *x);

float smoothstepv3(float x);
void smoothstepmaxv3(float *max, float *x);
float smoothstepa3(float x);
void smoothstepmaxa3(float *max, float *x);
void smoothstepmina3(float *min, float *x);

float intsmooth(float a, float b);
float intsmoothsimple(float a);

uint32_t pascalTriangle(uint8_t, uint8_t);
float smoothstepInttoFloat(uint32_t startPos, uint32_t endPos, uint32_t curPos);

#endif /* SMOOTHSTEP_H_ */
