/*
 * Utils.h
 *
 *  Created on: 21.01.2020
 *      Author: Martin
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

#include "main.h"

uint8_t DWT_Delay_Init(void);

uint32_t DWT_get_us(void);
void DWT_Delay_us(volatile uint32_t);

uint8_t findParaInt (char *, uint16_t, int32_t *);
uint8_t findParaFloat (char *, uint16_t, float *);

float clamp(float, float, float);

#endif /* INC_UTILS_H_ */
