/*
 * Smoothstep.c
 *
 *  Created on: 09.06.2021
 *      Author: BER83WI
 */

#include "Smoothstep.h"
//#include "main.h"

#include "stdlib.h"
#include "math.h"

#ifndef SMOOTHGRADE
SMOOTHGRADE 3
#endif

//Grad 1
float smoothstepfloat1(float x) {
  return x;
}

float intsmooth1(float a, float b) {
	return (a - b) * (a - b) / 2;
}

float intsmoothsimple1(float a) {
	return (a * a) / 2;
}

//Grad 2
float smoothstepfloat2(float x) {
  // Scale, bias and saturate x to 0..1 range
//  x = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
  // Evaluate polynomial
  return x * x * (3 - 2 * x);
}

float intsmooth2(float a, float b) {
	return (a*a*a*a - 2*a*a*a)/2-(b*b*b*b - 2*b*b*b)/2;
}

float intsmoothsimple2(float a) {
	return (a*a*a*a - 2*a*a*a)/2;
}

//Grad 3
float smoothstepfloat3(float x) {
  // Scale, and clamp x to 0..1 range
//  x = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
  // Evaluate polynomial
  return x * x * x * (x * (x * 6 - 15) + 10);
}

float intsmooth3(float a, float b) {
	return (-pow(6,6) + 3*(pow(3,5)) - 5*(pow(b,4))/2) - (-pow(a,6) + 3*(pow(a,5)) - 5*(pow(a,4))/2);
}

float intsmoothsimple3(float a) {
	return (-pow(a,6) + 3*(pow(a,5)) - 5*(pow(a,4))/2);
}

//Grad n
uint32_t pascalTriangle(uint8_t a, uint8_t b) {
  uint32_t result = 1;
  for(uint8_t i = 0; i < b; ++i){
    result *= ((a - i) / (i + 1));
  }
  return result;
}

float smoothstepfloat(float x) {
  float result = 0;
  for (uint8_t n = 0; n <= SMOOTHGRADE; ++n) {
    result += (pascalTriangle(-(SMOOTHGRADE)-1, n) * pascalTriangle(2 * SMOOTHGRADE + 1, SMOOTHGRADE - n) * pow(x, SMOOTHGRADE + n + 1));
  }
  return result;
}

float intsmooth(float a, float b) {
	return 1;
}

float intsmoothsimple(float a) {
	return 1;
}

//Convinience Aufrufe
float smoothstepint(uint32_t startPos, uint32_t endPos, uint32_t curPos) {
	return smoothstepfloat((float)curPos/(abs((int)(endPos + startPos))));
}

float smoothstepint2(uint32_t startPos, uint32_t endPos, uint32_t curPos) {
	return smoothstepfloat2((float)curPos/(abs((int)(endPos + startPos))));
}

float smoothstepint3(uint32_t startPos, uint32_t endPos, uint32_t curPos) {
	return smoothstepfloat3((float)curPos/(abs((int)(endPos - startPos))));
}

//Berechnungen Grad 2
float smoothstepv2(float x) {
	return 6 * (x - x * x);
}

void smoothstepmaxv2(float *max, float *x) {
	*max = 1.5;
	*x = 0.5;
}

float smoothstepa2(float x) {
	return 6 - 12 * x;
}

void smoothstepmaxa2(float *max, float *x) {
	*max = 6;
	*x = 0;
}

void smoothstepmina2(float *min, float *x) {
	*min = -6;
	*x = 1;
}

//Berechnungen Grad 3
float smoothstepv3(float x) {
	float tempfloat = x * x - x;
	return 30 * tempfloat * tempfloat;
}

void smoothstepmaxv3(float *max, float *x) {
	*max = 5.7735;
	*x = 0.21132;
}

float smoothstepa3(float x) {
	return 60 * x * (1 - 3 * x + 2 * x * x);
}

void smoothstepmaxa3(float *max, float *x) {
	*max = 5.7735;
	*x = 0.21132;
}

void smoothstepmina3(float *min, float *x) {
	*min = -5.7735;
	*x = 0.78868;
}

float smoothstepInttoFloat(uint32_t startPos, uint32_t endPos, uint32_t curPos) {
	return (float)curPos/(abs((int)(endPos + startPos)));
}
